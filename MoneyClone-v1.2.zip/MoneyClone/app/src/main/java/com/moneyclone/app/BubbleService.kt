package com.moneyclone.app
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/** Floating bubble: tap to expand the clone list, drag to move. */
class BubbleService : Service() {
    private var wm: WindowManager? = null
    private var box: LinearLayout? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int { if (box == null) show(); return START_STICKY }

    private fun pill(txt: String, size: Float) = TextView(this).apply {
        text = txt; textSize = size; setTextColor(Color.WHITE); setPadding(36, 22, 36, 22)
        background = GradientDrawable().apply { setColor(0xEE16211D.toInt()); cornerRadius = 60f }
    }

    private fun show() {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        val w = getSystemService(WindowManager::class.java); wm = w
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 400 }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; box = root
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val bubble = pill("💰", 26f)
        root.addView(bubble); root.addView(list)
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    lp.x = sx + dx; lp.y = sy + dy; w.updateViewLayout(root, lp); true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (list.visibility == View.VISIBLE) list.visibility = View.GONE
                        else {
                            list.removeAllViews()
                            val cl = Prefs.clones(this)
                            if (cl.isEmpty()) list.addView(pill("No clones yet", 14f))
                            cl.forEach { c -> list.addView(pill(c.name, 14f).apply { setOnClickListener { WorkProfileEngine.open(this@BubbleService, c.pkg); list.visibility = View.GONE } }) }
                            list.visibility = View.VISIBLE
                        }
                    }
                    true
                }
                else -> false
            }
        }
        w.addView(root, lp)
    }

    override fun onDestroy() { box?.let { wm?.removeView(it) }; box = null }
    override fun onBind(i: Intent?): IBinder? = null
}
